Note: Scripts support remote folder (does not have to be in same folder)

edit text (*.mdt)
    1] decrypt
    2] decode to txt
    * edit text, and mod XML to help
    3] encode to bin
    4] encrypt

MDT_2_TXT - Steps 1+2
TXT_2_MDT - Steps 3+4

edit png works
    1] decrypt
    (optional) See content with AssetStudio
    UABE 2023:
        decompress
        export png from Texture2D
    * edit png with transperancy (not paint.exe!)
    UABE 2023:
        import into Texture2D
        (optional) remove *.resS because not needed
    UABE 2019:
        compress
    (optional) Verify before==after with AssetStudio
    4] encrypt














